module.exports = {
  cookieSecret: 'microblogbyvoid',
  db: 'microblog',
  host: 'localhost',
};