MICROBLOG
=========


Introduction
-------------
This is a microblog sample that shows you how to coding with nodejs and make excellent web pages . This is a reconstruction version of the microblog project in [node.js web开发指南](http://book.douban.com/subject/10789820/).
As known to all,this book publiced in 2012,so its style is too old in coding with nodejs.Between 2012 and 2015 ,nodejs changed a lot and more and more third-party libraies appeared in front of us.However ,this book just only show us the technical combination by the end of 2012.This is this project' intention that tells you how to coding in the technical combination of 2015.

Key words 
-------------
> - [nodeV0.10.33](https://nodejs.org/),this is the latest version of node so far in 2015.
> - [jadeV1.9.2](http://jade-lang.com/),now jade is the default template engine in the Express,not any more ejs.
> - [ExpressV4.12.1](http://expressjs.com/).this version of express web strcture changed a lot in the past 3 years.The most significant change is that some functionalities in express2.x were divided into independent middlewares in express4.x
> - [MongoDBV3.0.2](http://mongodb.org/) and [MongooseV4.0.1](http://mongoosejs.com/) .Mongoose is a elegant mongodb object modeling for node.js.In 2012,it has not been released yet.Now we can use it to manipulate the MongoDB database instead of native nodejs for MongoDB. It is more convenient!

Usage
-------------
> - Download this package and unzip it. 
> - before run it,please make sure you have installed the [nodejs](https://nodejs.org/) CL ,[npm](https://www.npmjs.com/package/npm) and [MongoDB](http://mongodb.org/) environment in your machine.if not,get to
intall and config them.
> - enter in the microblog directory and run commands in this order.
> - `cd microblog` `npm install` `npm start`
> - open the browser and type [http://localhost:3000](http://localhost:3000) to check the page.

