module.exports={
    "ip":"localhost",
    "db":"microblog",
    "host":27071
};
